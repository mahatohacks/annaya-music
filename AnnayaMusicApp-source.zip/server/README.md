# Annaya Music shared catalog server

Self-hosted JSON and audio-file service for Annaya Music App. Node.js 20+ is used; the container setup uses Node 22. Persist `/data` because it contains the catalog and uploaded music.

## Render deployment

Use the root-level `render.yaml` and follow `DEPLOY_RENDER.md`. Render supplies HTTPS and the service URL. The Blueprint attaches persistent storage at `/data`; keep it to one server instance because this starter uses a local file catalog. Persistent disks require a paid Render web service.

Set a strong `ADMIN_PASSWORD` during Blueprint setup. Production startup fails if it is missing. The starter account name is `admin`; local Docker keeps the requested development password. Render generates `TOKEN_SECRET` automatically. Do not commit credentials.

## Local Docker deployment

1. Copy `.env.example` to `.env`.
2. Set `TOKEN_SECRET` to a long random value. Keep `.env` private.
3. Change `ADMIN_PASSWORD` before exposing the server to the public internet.
4. Run `docker compose up -d --build`.
5. Put the service behind HTTPS. The Android app refuses cleartext HTTP.

The server accepts MP3/AAC-family audio uploads up to 1 GB per song. It does not retrieve or download audio from YouTube.

## API summary

- `POST /api/admin/login` — admin session.
- `POST /api/admin/songs` — raw audio upload (admin bearer token; `X-File-Name` and audio `Content-Type` headers).
- `DELETE /api/admin/songs/:id` — remove song (admin bearer token).
- `GET /api/catalog` — shared song list.
- `GET /api/songs/:id/audio` — stream song.
- `POST /api/session` — anonymous listener session.
- `GET /api/playlists` and `PUT /api/playlists` — shared playlists.

This starter server has no account system for listeners, no per-user permissions for playlist changes, and no automatic cloud backup. For public production use, add abuse controls, monitoring, and backups.

