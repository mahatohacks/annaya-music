const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pipeline } = require('node:stream/promises');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || (process.env.NODE_ENV === 'production' ? '' : 'Admin@2026#');
if (!ADMIN_PASSWORD) { console.error('Set ADMIN_PASSWORD before starting in production.'); process.exit(1); }
const TOKEN_SECRET = process.env.TOKEN_SECRET || crypto.randomBytes(32).toString('hex');
const DATA = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const SONGS = path.join(DATA, 'songs');
const DB = path.join(DATA, 'catalog.json');
const MAX_UPLOAD = 1024 * 1024 * 1024;
fs.mkdirSync(SONGS, { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({ songs: [], playlists: [] }, null, 2));
let writeQueue = Promise.resolve();
const readDb = () => JSON.parse(fs.readFileSync(DB, 'utf8'));
function saveDb(db) {
  writeQueue = writeQueue.then(() => fs.promises.writeFile(DB + '.tmp', JSON.stringify(db, null, 2)).then(() => fs.promises.rename(DB + '.tmp', DB)));
  return writeQueue;
}
const send = (res, status, body, headers = {}) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-File-Name', 'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS', ...headers }); res.end(JSON.stringify(body)); };
const b64 = value => Buffer.from(value).toString('base64url');
function makeToken(payload) { const data = b64(JSON.stringify({ ...payload, exp: Date.now() + 1000 * 60 * 60 * 24 * 14 })); const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(data).digest('base64url'); return `${data}.${sig}`; }
function decodeToken(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const [data, sig] = token.split('.'); if (!data || !sig) return null;
  const actual = crypto.createHmac('sha256', TOKEN_SECRET).update(data).digest();
  let provided; try { provided = Buffer.from(sig, 'base64url'); } catch { return null; }
  if (provided.length !== actual.length || !crypto.timingSafeEqual(provided, actual)) return null;
  try { const payload = JSON.parse(Buffer.from(data, 'base64url').toString()); return payload.exp > Date.now() ? payload : null; } catch { return null; }
}
async function jsonBody(req, max = 2 * 1024 * 1024) {
  const parts = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > max) throw Object.assign(new Error('Request body too large'), { status: 413 }); parts.push(chunk); }
  return JSON.parse(Buffer.concat(parts).toString('utf8') || '{}');
}
function safeName(name) { return path.basename(decodeURIComponent(name || 'song.mp3')).replace(/[\\/:*?"<>|\x00-\x1F]/g, '_').slice(0, 160) || 'song.mp3'; }
async function handler(req, res) {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (req.method === 'GET' && u.pathname === '/health') return send(res, 200, { ok: true, app: 'Annaya Music Catalog' });
    if (req.method === 'POST' && u.pathname === '/api/admin/login') {
      const data = await jsonBody(req, 16 * 1024);
      const a = Buffer.from(String(data.username || '')); const b = Buffer.from(ADMIN_USERNAME);
      const c = Buffer.from(String(data.password || '')); const d = Buffer.from(ADMIN_PASSWORD);
      const userOk = a.length === b.length && crypto.timingSafeEqual(a, b);
      const passOk = c.length === d.length && crypto.timingSafeEqual(c, d);
      if (!userOk || !passOk) return send(res, 401, { error: 'Invalid username or password' });
      return send(res, 200, { token: makeToken({ role: 'admin', sub: ADMIN_USERNAME }) });
    }
    if (req.method === 'POST' && u.pathname === '/api/session') return send(res, 200, { token: makeToken({ role: 'listener', sub: crypto.randomUUID() }) });
    if (req.method === 'GET' && u.pathname === '/api/catalog') {
      const db = readDb();
      return send(res, 200, { songs: db.songs.map(({ id, title, filename, size, createdAt }) => ({ id, title, filename, size, createdAt, audioUrl: `/api/songs/${id}/audio` })) });
    }
    if (req.method === 'GET' && u.pathname === '/api/playlists') return send(res, 200, { playlists: readDb().playlists });
    if (req.method === 'PUT' && u.pathname === '/api/playlists') {
      if (!decodeToken(req)) return send(res, 401, { error: 'Listener session required' });
      const input = await jsonBody(req); const incoming = Array.isArray(input.playlists) ? input.playlists : [];
      const db = readDb();
      const byId = new Map(db.playlists.map(p => [p.id, p]));
      for (const item of incoming.slice(0, 500)) {
        if (!item || typeof item.name !== 'string') continue;
        const id = String(item.id || crypto.randomUUID()).slice(0, 80);
        byId.set(id, { id, name: item.name.trim().slice(0, 100), tracks: Array.isArray(item.tracks) ? [...new Set(item.tracks.map(String))].slice(0, 5000) : [], updatedAt: new Date().toISOString() });
      }
      db.playlists = [...byId.values()]; await saveDb(db); return send(res, 200, { playlists: db.playlists });
    }
    const audio = u.pathname.match(/^\/api\/songs\/([0-9a-f-]+)\/audio$/i);
    if (req.method === 'GET' && audio) {
      const song = readDb().songs.find(s => s.id === audio[1]);
      if (!song) return send(res, 404, { error: 'Song not found' });
      const file = path.join(SONGS, song.diskName);
      if (!fs.existsSync(file)) return send(res, 404, { error: 'Audio file missing' });
      res.writeHead(200, { 'Content-Type': song.mime, 'Content-Length': song.size, 'Accept-Ranges': 'bytes', 'Access-Control-Allow-Origin': '*' });
      return fs.createReadStream(file).pipe(res);
    }
    if (req.method === 'POST' && u.pathname === '/api/admin/songs') {
      const user = decodeToken(req); if (!user || user.role !== 'admin') return send(res, 401, { error: 'Admin sign-in required' });
      const mime = String(req.headers['content-type'] || '').split(';')[0];
      const name = safeName(req.headers['x-file-name'] || 'song.mp3');
      if (!/^audio\/(mpeg|mp4|aac|x-aac|mp3|m4a|octet-stream)$/i.test(mime)) return send(res, 415, { error: 'Upload an MP3 or AAC audio file' });
      const ext = path.extname(name).toLowerCase();
      if (!['.mp3', '.aac', '.m4a', '.mp4'].includes(ext)) return send(res, 415, { error: 'File extension must be MP3 or AAC' });
      const id = crypto.randomUUID(); const diskName = id + ext; const file = path.join(SONGS, diskName); let size = 0;
      const limiter = new (require('node:stream').Transform)({ transform(chunk, enc, cb) { size += chunk.length; cb(size > MAX_UPLOAD ? Object.assign(new Error('Upload exceeds 1 GB'), { status: 413 }) : null, chunk); } });
      try { await pipeline(req, limiter, fs.createWriteStream(file, { flags: 'wx' })); }
      catch (err) { fs.promises.rm(file, { force: true }).catch(() => {}); throw err; }
      if (!size) { await fs.promises.rm(file, { force: true }); return send(res, 400, { error: 'Empty audio file' }); }
      const db = readDb(); const song = { id, title: decodeURIComponent(name).replace(/\.(mp3|aac|m4a|mp4)$/i, ''), filename: name, diskName, size, mime, createdAt: new Date().toISOString() };
      db.songs.push(song); await saveDb(db); return send(res, 201, { song: { ...song, audioUrl: `/api/songs/${id}/audio` } });
    }
    const remove = u.pathname.match(/^\/api\/admin\/songs\/([0-9a-f-]+)$/i);
    if (req.method === 'DELETE' && remove) {
      const user = decodeToken(req); if (!user || user.role !== 'admin') return send(res, 401, { error: 'Admin sign-in required' });
      const db = readDb(); const i = db.songs.findIndex(s => s.id === remove[1]); if (i < 0) return send(res, 404, { error: 'Song not found' });
      const [song] = db.songs.splice(i, 1); await saveDb(db); await fs.promises.rm(path.join(SONGS, song.diskName), { force: true });
      db.playlists.forEach(p => { p.tracks = (p.tracks || []).filter(id => id !== song.id); }); await saveDb(db); return send(res, 200, { ok: true });
    }
    return send(res, 404, { error: 'Not found' });
  } catch (error) {
    console.error(error);
    return send(res, error.status || 500, { error: error.status ? error.message : 'Server error' });
  }
}
http.createServer((req, res) => handler(req, res)).listen(PORT, HOST, () => console.log(`Annaya Music server listening on ${HOST}:${PORT}`));

