package com.annaya.music

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

private data class Track(val uri: String, val title: String)
private data class RemoteTrack(val id: String, val title: String, val audioUrl: String, val filename: String)
private data class Playlist(val id: String, val name: String, val tracks: MutableList<String>)

class MainActivity : Activity() {
    private val ink = Color.rgb(20, 31, 29)
    private val paper = Color.rgb(248, 246, 239)
    private val muted = Color.rgb(112, 120, 114)
    private val coral = Color.rgb(201, 92, 69)
    private val mint = Color.rgb(219, 236, 224)
    private val tracks = mutableListOf<Track>()
    private val remoteTracks = mutableListOf<RemoteTrack>()
    private val playlists = mutableListOf<Playlist>()
    private val sharedPlaylists = mutableListOf<Playlist>()
    private var currentTrack: Track? = null
    private var player: MediaPlayer? = null
    private var activePlaylist: Playlist? = null
    private var activeRemotePlaylist: Playlist? = null
    private lateinit var content: LinearLayout
    private lateinit var nowPlaying: TextView
    private var tab = "Offline"
    private var uploadSelection = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = ink; window.navigationBarColor = ink
        loadLibrary(); buildShell(); showTab("Offline")
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(paper) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(18)); setBackgroundColor(ink) }
        header.addView(label("ANNAYA  /  MUSIC", 12, Color.rgb(188, 207, 192), true))
        header.addView(label("A little room\nfor every song.", 28, Color.WHITE, true).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(header)
        val nav = LinearLayout(this).apply { setPadding(dp(16), dp(12), dp(16), dp(12)); setBackgroundColor(ink) }
        listOf("Offline", "Online", "Admin").forEach { name ->
            nav.addView(Button(this).apply {
                text = name; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (name == "Offline") coral else Color.rgb(55, 69, 63)))
                setOnClickListener { showTab(name) }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(7) })
        }
        root.addView(nav)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(26)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nowPlaying = label("Nothing playing yet", 13, Color.WHITE, false)
        val playerBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12)); setBackgroundColor(ink) }
        playerBar.addView(nowPlaying, LinearLayout.LayoutParams(0, -2, 1f))
        playerBar.addView(Button(this).apply {
            text = "Ⅱ"; textSize = 17f; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(coral)); setOnClickListener { togglePlayback() }
        }, LinearLayout.LayoutParams(dp(52), dp(46)))
        root.addView(playerBar); setContentView(root)
    }

    private fun showTab(name: String) { tab = name; content.removeAllViews(); when (name) { "Online" -> onlinePage(); "Admin" -> adminPage(); else -> offlinePage() } }

    private fun offlinePage() {
        content.addView(label("YOUR LIBRARY", 11, coral, true))
        content.addView(label("Songs, close at hand", 24, ink, true).apply { setPadding(0, dp(5), 0, dp(16)) })
        val stat = LinearLayout(this).apply { setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundColor(mint); orientation = LinearLayout.VERTICAL }
        stat.addView(label("${tracks.size} songs saved on this device", 15, ink, true))
        stat.addView(label("MP3 and AAC files stay available offline, even without a connection.", 13, muted, false).apply { setPadding(0, dp(5), 0, 0) })
        content.addView(stat, marginBottom(14))
        val actions = LinearLayout(this)
        actions.addView(Button(this).apply { text = "＋  Add songs"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(tint(coral)); setOnClickListener { uploadSelection = false; chooseAudio() } }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(7) })
        actions.addView(Button(this).apply { text = "＋  Playlist"; isAllCaps = false; setTextColor(ink); setBackgroundTintList(tint(Color.rgb(231, 226, 215))); setOnClickListener { createPlaylist(false) } }, LinearLayout.LayoutParams(0, dp(50), 1f))
        content.addView(actions, marginBottom(18))
        if (playlists.isNotEmpty()) {
            content.addView(label("PLAYLISTS", 11, coral, true), marginBottom(7))
            playlists.forEach { p ->
                content.addView(label("♫   ${p.name}   ·   ${p.tracks.size} songs", 14, ink, true).apply {
                    setPadding(dp(13), dp(13), dp(13), dp(13)); setBackgroundColor(Color.WHITE)
                    setOnClickListener { activePlaylist = p; Toast.makeText(this@MainActivity, "Tap a song, then long press it to add to ${p.name}.", Toast.LENGTH_LONG).show() }
                }, marginBottom(6))
            }
        }
        content.addView(label(if (tracks.isEmpty()) "GET STARTED" else "ALL SONGS", 11, coral, true), marginBottom(8))
        if (tracks.isEmpty()) {
            content.addView(label("Your next favorite is waiting here. Add audio files from your device to build an offline library.", 15, muted, false).apply { setPadding(dp(15), dp(18), dp(15), dp(18)); setBackgroundColor(Color.WHITE) })
        } else tracks.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)); setBackgroundColor(Color.WHITE) }
            row.addView(label(String.format("%02d", index + 1), 12, coral, false), LinearLayout.LayoutParams(dp(31), -2))
            row.addView(label(track.title, 14, ink, true).apply { maxLines = 2; setPadding(dp(4), 0, dp(6), 0) }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply { text = "▶"; setTextColor(coral); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { playLocal(track) } })
            row.setOnLongClickListener { val p = activePlaylist; if (p != null) { if (track.uri !in p.tracks) p.tracks.add(track.uri); activePlaylist = null; saveLibrary(); showTab("Offline"); Toast.makeText(this, "Added to ${p.name}", Toast.LENGTH_SHORT).show() } else removeTrack(track); true }
            content.addView(row, marginBottom(4))
        }
    }

    private fun onlinePage() {
        content.addView(label("LISTEN ONLINE", 11, coral, true))
        content.addView(label("Shared songs & playlists", 24, ink, true).apply { setPadding(0, dp(5), 0, dp(8)) })
        content.addView(label("Connect to the shared catalog to stream songs and sync playlists across listeners.", 14, muted, false), marginBottom(12))
        val baseInput = EditText(this).apply { hint = "https://your-server.example"; textSize = 14f; isSingleLine = true; setPadding(dp(14), 0, dp(12), 0); setBackgroundColor(Color.WHITE); setText(getServerUrl()) }
        content.addView(baseInput, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        content.addView(Button(this).apply { text = "Refresh shared songs"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(tint(coral)); setOnClickListener { saveServer(baseInput.text.toString()); fetchSharedCatalog() } }, marginBottom(14))
        content.addView(label("YOUTUBE", 11, coral, true))
        val query = EditText(this).apply { hint = "Artist, song, or album"; textSize = 14f; isSingleLine = true; setPadding(dp(14), 0, dp(12), 0); setBackgroundColor(Color.WHITE) }
        content.addView(query, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8); bottomMargin = dp(7) })
        content.addView(Button(this).apply {
            text = "Search YouTube  ↗"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(tint(ink))
            setOnClickListener { val q = query.text.toString().trim(); if (q.isBlank()) query.error = "Enter a song or artist" else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")))) }
        }, marginBottom(14))
        content.addView(label("SHARED PLAYLISTS", 11, coral, true), marginBottom(7))
        content.addView(Button(this).apply { text = "＋  New shared playlist"; isAllCaps = false; setTextColor(ink); setBackgroundTintList(tint(Color.rgb(231, 226, 215))); setOnClickListener { createPlaylist(true) } }, marginBottom(8))
        if (sharedPlaylists.isNotEmpty()) sharedPlaylists.forEach { p -> content.addView(label("♫   ${p.name}   ·   ${p.tracks.size} songs", 13, if (activeRemotePlaylist?.id == p.id) coral else ink, true).apply { setPadding(dp(12), dp(11), dp(12), dp(11)); setBackgroundColor(Color.WHITE); setOnClickListener { activeRemotePlaylist = p; toast("Selected ${p.name}. Long press a song to add it.") } }, marginBottom(4)) }
        if (remoteTracks.isEmpty()) content.addView(label("No shared songs loaded yet. Enter the server address and refresh.", 13, muted, false).apply { setPadding(0, dp(10), 0, dp(10)) })
        remoteTracks.forEach { song ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(8), dp(8)); setBackgroundColor(Color.WHITE) }
            row.addView(label("${song.title}\nShared catalog", 14, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply { text = "▶"; setTextColor(coral); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { stream(song) } })
            row.addView(Button(this).apply { text = "↓"; setTextColor(coral); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { downloadOffline(song) } })
            row.setOnLongClickListener { val p = activeRemotePlaylist ?: sharedPlaylists.firstOrNull(); if (p == null) { Toast.makeText(this@MainActivity, "Create a shared playlist first.", Toast.LENGTH_SHORT).show() } else { if (song.id !in p.tracks) p.tracks.add(song.id); syncPlaylists(); activeRemotePlaylist = null; Toast.makeText(this@MainActivity, "Added to ${p.name}", Toast.LENGTH_SHORT).show() }; true }
            content.addView(row, marginBottom(4))
        }
        content.addView(label("Tap ▶ to stream, ↓ to save for offline listening, or long press a song to add it to a shared playlist.", 12, muted, false).apply { setPadding(0, dp(10), 0, 0) })
    }

    private fun adminPage() {
        content.addView(label("LIBRARY MANAGER", 11, coral, true))
        content.addView(label("Admin sign in", 24, ink, true).apply { setPadding(0, dp(5), 0, dp(8)) })
        content.addView(label("Server address", 12, muted, true), marginBottom(5))
        val base = EditText(this).apply { hint = "https://your-server.example"; textSize = 14f; isSingleLine = true; setPadding(dp(14), 0, dp(12), 0); setBackgroundColor(Color.WHITE); setText(getServerUrl()) }
        content.addView(base, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(9) })
        content.addView(label("Username", 12, muted, true), marginBottom(5))
        val username = EditText(this).apply { setText("admin"); textSize = 14f; isSingleLine = true; setPadding(dp(14), 0, dp(12), 0); setBackgroundColor(Color.WHITE) }
        content.addView(username, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) })
        content.addView(label("Password", 12, muted, true), marginBottom(5))
        val password = EditText(this).apply { hint = "Admin password"; inputType = 129; textSize = 14f; isSingleLine = true; setPadding(dp(14), 0, dp(12), 0); setBackgroundColor(Color.WHITE) }
        content.addView(password, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })
        val status = label(if (getToken().isBlank()) "Not signed in" else "Admin session saved on this device", 12, muted, false)
        content.addView(status, marginBottom(8))
        content.addView(Button(this).apply {
            text = if (getToken().isBlank()) "Sign in" else "Sign out"; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(tint(coral))
            setOnClickListener {
                saveServer(base.text.toString())
                if (getToken().isNotBlank()) { setToken(""); status.text = "Signed out"; text = "Sign in" }
                else adminLogin(base.text.toString(), username.text.toString(), password.text.toString()) { ok, message -> status.text = message; (this as Button).text = if (ok) "Sign out" else "Sign in" }
            }
        }, marginBottom(14))
        content.addView(label("Upload MP3 / AAC songs", 16, ink, true), marginBottom(6))
        content.addView(label("After signing in, choose songs to publish them to the shared catalog. Listeners can stream them or save them offline.", 13, muted, false), marginBottom(9))
        content.addView(Button(this).apply {
            text = "Choose songs to upload"; isAllCaps = false; setTextColor(ink); setBackgroundTintList(tint(mint))
            setOnClickListener { if (getToken().isBlank()) Toast.makeText(this@MainActivity, "Sign in as admin first.", Toast.LENGTH_SHORT).show() else { uploadSelection = true; chooseAudio() } }
        }, marginBottom(12))
        content.addView(label("Local offline library · ${tracks.size} songs", 12, coral, true))
    }

    private fun chooseAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) }
        @Suppress("DEPRECATION") startActivityForResult(i, 41)
    }

    @Deprecated("Uses the platform document picker to select multiple audio files")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 41 || resultCode != RESULT_OK || data == null) return
        val found = mutableListOf<Uri>(); data.clipData?.let { clip -> for (i in 0 until clip.itemCount) found.add(clip.getItemAt(i).uri) }; if (found.isEmpty()) data.data?.let { found.add(it) }
        val doUpload = uploadSelection; uploadSelection = false
        found.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val title = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: uri.lastPathSegment ?: "Audio track"
                if (tracks.none { it.uri == uri.toString() }) tracks.add(Track(uri.toString(), title))
            } catch (_: Exception) { }
        }
        saveLibrary(); showTab(tab)
        if (doUpload) uploadFiles(found) else Toast.makeText(this, "Added ${found.size} file${if (found.size == 1) "" else "s"} to this device", Toast.LENGTH_SHORT).show()
    }

    private fun playLocal(track: Track) {
        try {
            player?.release(); currentTrack = track
            player = MediaPlayer().apply { setDataSource(this@MainActivity, Uri.parse(track.uri)); setOnCompletionListener { nowPlaying.text = "Finished · ${track.title}" }; setOnPreparedListener { start() }; prepareAsync() }
            nowPlaying.text = "Loading · ${track.title}"
        } catch (_: Exception) { nowPlaying.text = "Could not play · ${track.title}"; Toast.makeText(this, "This audio file could not be played.", Toast.LENGTH_SHORT).show() }
    }
    private fun stream(song: RemoteTrack) {
        try {
            val url = absoluteUrl(song.audioUrl); player?.release(); currentTrack = Track(url, song.title)
            player = MediaPlayer().apply { setDataSource(url); setOnCompletionListener { nowPlaying.text = "Finished · ${song.title}" }; setOnPreparedListener { start(); nowPlaying.text = "Streaming · ${song.title}" }; setOnErrorListener { _, _, _ -> nowPlaying.text = "Could not stream · ${song.title}"; true }; prepareAsync() }
            nowPlaying.text = "Connecting · ${song.title}"
        } catch (_: Exception) { Toast.makeText(this, "Check the server connection and try again.", Toast.LENGTH_SHORT).show() }
    }
    private fun togglePlayback() { val p = player ?: run { Toast.makeText(this, "Choose a song first.", Toast.LENGTH_SHORT).show(); return }; try { if (p.isPlaying) { p.pause(); nowPlaying.text = "Paused · ${currentTrack?.title ?: ""}" } else { p.start(); nowPlaying.text = "Playing · ${currentTrack?.title ?: ""}" } } catch (_: Exception) {} }

    private fun createPlaylist(shared: Boolean) {
        val input = EditText(this).apply { hint = "Playlist name"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(if (shared) "New shared playlist" else "New playlist").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().trim()
            if (name.isNotBlank() && playlists.none { it.name.equals(name, true) }) {
                val p = Playlist(UUID.randomUUID().toString(), name, mutableListOf()); playlists.add(p); saveLibrary()
                if (shared) { sharedPlaylists.add(p); activeRemotePlaylist = p; syncPlaylists() }
                showTab(if (shared) "Online" else "Offline"); Toast.makeText(this, "Playlist created.", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }
    private fun removeTrack(track: Track) {
        AlertDialog.Builder(this).setMessage("Remove ${track.title} from this library?").setNegativeButton("Cancel", null).setPositiveButton("Remove") { _, _ ->
            tracks.removeAll { it.uri == track.uri }; playlists.forEach { it.tracks.remove(track.uri) }
            if (track.uri.startsWith("file://")) runCatching { File(Uri.parse(track.uri).path!!).delete() }
            if (currentTrack?.uri == track.uri) { player?.release(); player = null; currentTrack = null; nowPlaying.text = "Nothing playing yet" }
            saveLibrary(); showTab("Offline")
        }.show()
    }

    private fun fetchSharedCatalog() {
        val base = getServerUrl(); if (base.isBlank()) { toast("Enter your hosted server address first."); return }
        Thread {
            try {
                val songs = JSONObject(api("GET", "$base/api/catalog")).getJSONArray("songs")
                val newTracks = mutableListOf<RemoteTrack>()
                for (i in 0 until songs.length()) { val x = songs.getJSONObject(i); newTracks.add(RemoteTrack(x.getString("id"), x.getString("title"), x.getString("audioUrl"), x.optString("filename", "song.mp3"))) }
                val lists = JSONObject(api("GET", "$base/api/playlists")).getJSONArray("playlists")
                val newLists = mutableListOf<Playlist>()
                for (i in 0 until lists.length()) { val x = lists.getJSONObject(i); val ids = x.optJSONArray("tracks") ?: JSONArray(); val members = mutableListOf<String>(); for (j in 0 until ids.length()) members.add(ids.getString(j)); newLists.add(Playlist(x.getString("id"), x.getString("name"), members)) }
                runOnUiThread { remoteTracks.clear(); remoteTracks.addAll(newTracks); sharedPlaylists.clear(); sharedPlaylists.addAll(newLists); saveLibrary(); showTab("Online"); toast("Loaded ${newTracks.size} shared songs.") }
            } catch (e: Exception) { runOnUiThread { toast("Could not reach the catalog. Check the server address.") } }
        }.start()
    }
    private fun syncPlaylists() {
        val base = getServerUrl(); if (base.isBlank()) { toast("Connect to your server to sync playlists."); return }
        Thread { try {
            val token = getOrCreateListenerToken(base)
            val arr = JSONArray(); sharedPlaylists.forEach { p -> val ids = JSONArray(); p.tracks.forEach { ids.put(it) }; arr.put(JSONObject().put("id", p.id).put("name", p.name).put("tracks", ids)) }
            api("PUT", "$base/api/playlists", JSONObject().put("playlists", arr).toString(), token)
        } catch (_: Exception) { runOnUiThread { toast("Playlist saved here, but could not sync yet.") } } }.start()
    }
    private fun getOrCreateListenerToken(base: String): String {
        val p = getSharedPreferences("annaya_config", MODE_PRIVATE); val current = p.getString("listenerToken", "") ?: ""; if (current.isNotBlank()) return current
        val token = JSONObject(api("POST", "$base/api/session", "{}")).getString("token"); p.edit().putString("listenerToken", token).apply(); return token
    }
    private fun adminLogin(baseInput: String, username: String, password: String, done: (Boolean, String) -> Unit) {
        if (baseInput.isBlank()) { done(false, "Enter a server address"); return }
        Thread { try {
            saveServer(baseInput)
            val data = JSONObject(api("POST", "${baseInput.trimEnd('/')}/api/admin/login", JSONObject().put("username", username).put("password", password).toString()))
            setToken(data.getString("token")); runOnUiThread { done(true, "Signed in as admin") }
        } catch (_: Exception) { runOnUiThread { done(false, "Sign in failed. Check the server and credentials.") } } }.start()
    }
    private fun uploadFiles(uris: List<Uri>) {
        val base = getServerUrl(); val token = getToken(); if (base.isBlank() || token.isBlank()) { toast("Set the server address and sign in first."); return }
        Thread { var ok = 0; var failed = 0
            for (uri in uris) try {
                val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "song.mp3"
                val mime = contentResolver.getType(uri) ?: "audio/mpeg"
                val conn = (URL("${base.trimEnd('/')}/api/admin/songs").openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true; setRequestProperty("Authorization", "Bearer $token"); setRequestProperty("Content-Type", mime); setRequestProperty("X-File-Name", URLEncoder.encode(name, "UTF-8")) }
                contentResolver.openInputStream(uri)!!.use { source -> conn.outputStream.use { source.copyTo(it) } }
                if (conn.responseCode in 200..299) ok++ else failed++
                conn.disconnect()
            } catch (_: Exception) { failed++ }
            runOnUiThread { toast("Uploaded $ok song${if (ok == 1) "" else "s"}${if (failed > 0) " · $failed failed" else ""}"); if (ok > 0) { fetchSharedCatalog() } }
        }.start()
    }
    private fun downloadOffline(song: RemoteTrack) {
        Thread { try {
            val url = URL(absoluteUrl(song.audioUrl)); val conn = url.openConnection(); conn.connectTimeout = 15000; conn.readTimeout = 60000
            val dir = File(filesDir, "music").apply { mkdirs() }; val ext = File(song.filename).extension.let { if (it.isBlank()) "mp3" else it.lowercase() }.let { ".$it" }
            val file = File(dir, UUID.randomUUID().toString() + ext); conn.getInputStream().use { input -> file.outputStream().use { input.copyTo(it) } }
            val track = Track(Uri.fromFile(file).toString(), song.title); if (tracks.none { it.uri == track.uri }) tracks.add(track); saveLibrary()
            runOnUiThread { toast("Saved for offline listening."); if (tab == "Offline") showTab("Offline") }
        } catch (_: Exception) { runOnUiThread { toast("Could not download this song. Check your connection.") } } }.start()
    }

    private fun api(method: String, url: String, body: String? = null, token: String? = null): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = method; connectTimeout = 12000; readTimeout = 20000; setRequestProperty("Accept", "application/json"); if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }; if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token") }
        if (body != null) conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode; val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val result = stream?.bufferedReader()?.use { it.readText() } ?: "{}"; conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code: $result")
        return result
    }
    private fun absoluteUrl(path: String): String = if (path.startsWith("http://") || path.startsWith("https://")) path else getServerUrl().trimEnd('/') + "/" + path.trimStart('/')
    private fun getServerUrl() = getSharedPreferences("annaya_config", MODE_PRIVATE).getString("serverUrl", "") ?: ""
    private fun saveServer(value: String) { getSharedPreferences("annaya_config", MODE_PRIVATE).edit().putString("serverUrl", value.trim().trimEnd('/')).apply() }
    private fun getToken() = getSharedPreferences("annaya_config", MODE_PRIVATE).getString("adminToken", "") ?: ""
    private fun setToken(value: String) { getSharedPreferences("annaya_config", MODE_PRIVATE).edit().putString("adminToken", value).apply() }

    private fun loadLibrary() {
        val p = getSharedPreferences("annaya_library", MODE_PRIVATE)
        try {
            val arr = JSONArray(p.getString("tracks", "[]")); for (i in 0 until arr.length()) { val x = arr.getJSONObject(i); tracks.add(Track(x.getString("uri"), x.getString("title"))) }
            val lists = JSONArray(p.getString("playlists", "[]")); for (i in 0 until lists.length()) { val x = lists.getJSONObject(i); val items = x.getJSONArray("tracks"); val ids = mutableListOf<String>(); for (j in 0 until items.length()) ids.add(items.getString(j)); playlists.add(Playlist(x.optString("id", UUID.randomUUID().toString()), x.getString("name"), ids)) }
        } catch (_: Exception) { tracks.clear(); playlists.clear() }
    }
    private fun saveLibrary() {
        val arr = JSONArray(); tracks.forEach { arr.put(JSONObject().put("uri", it.uri).put("title", it.title)) }
        val lists = JSONArray(); playlists.forEach { p -> val ids = JSONArray(); p.tracks.forEach { ids.put(it) }; lists.put(JSONObject().put("id", p.id).put("name", p.name).put("tracks", ids)) }
        getSharedPreferences("annaya_library", MODE_PRIVATE).edit().putString("tracks", arr.toString()).putString("playlists", lists.toString()).apply()
    }
    private fun tint(color: Int) = android.content.res.ColorStateList.valueOf(color)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setLineSpacing(dp(2).toFloat(), 1f) }
    private fun marginBottom(value: Int) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(value) }
    private fun dp(n: Int): Int = (n * resources.displayMetrics.density + 0.5f).toInt()
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}




